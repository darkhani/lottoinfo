<html>
<?php
echo "1";
$conn=mysqli_connect("localhost","darkhani","a4353488a","darkhani");
$sql_user = "CREATE OR REPLACE TABLE USER (id VARCHAR(20) PRIMARY KEY, passwd VARCHAR(100) NOT NULL, user_role CHAR(3) NOT NULL, email VARCHAR(30));";
mysqli_query($conn, $sql_user);
echo "2";
$sql_ques = <<<EOT CREATE OR REPLACE TABLE QUESTION (date_type VARCHAR(30),
no VARCHAR(3) PRIMARY KEY, 
ques VARCHAR(1000) NOT NULL,
item1 VARCHAR(1000) NOT NULL, 
item2 VARCHAR(1000) NOT NULL, 
item3 VARCHAR(1000) NOT NULL, 
item4 VARCHAR(1000) NOT NULL, 
answer CHAR(1) NOT NULL, 
jimun VARCHAR(1000) NULL,
jimun_type_code CHAR(2) NOT NULL, 
jimun_url VARCHAR(1000) NULL
);
EOT;
mysqli_query($conn, $sql_ques);
echo "create sql_ques";
$sql_role = "CREATE OR REPLACE TABLE ROLE (role_id CHAR(3) PRIMARY KEY, role_name VARCHAR(10) NOT NULL);";
mysqli_query($conn, $sql_role);
echo "create sql_role";
$sql_quesinfo = <<< EOT CREATE OR REPLACE TABLE QUESINFO (date_type VARCHAR(30) PRIMARY KEY,
exam_year VARCHAR(5) NOT NULL,
exam_month VARCHAR(2) NOT NULL,
exam_full_name VARCHAR(100) NOT NULL,
exam_type_code VARCHAR(5) NOT NULL
);
EOT;
mysqli_query($conn, $sql_quesinfo);
echo "create sql_quesinfo";
$sql_create_admin = <<< EOT 
INSERT INTO USER (id, passwd, user_role, email) 
VALUES ('admin','a123456b!','000','admin@tegine.com');
EOT;
echo "insert admin";
mysqli_query($conn, $sql_create_admin);

?>

</html>
