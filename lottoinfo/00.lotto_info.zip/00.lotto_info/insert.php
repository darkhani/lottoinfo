<?php
$con=mysqli_connect("localhost","darkhani","a4353488a","darkhani");
// Check connection
$today1 = date("Y");
$today2 = date("m");
$today3 = date("d");
$today=$today1+"-".$today2."-".$today3;

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$s = strtolower($_POST[ID]);
if ( $s=="admin"||$s=="root"){ 
echo'
  <script>
  window.location.replace("index.php?page=1");
  </script>
  ';

mysqli_close($con);
}

$sql="INSERT INTO gesipan (ID, title, body,inputDay,nid)
VALUES
('$_POST[ID]','$_POST[title]','$_POST[body]',$today,'$_POST[nid]')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }

echo'
  <script>
  window.location.replace("index.php?page=1");
  </script>
  ';

mysqli_close($con);
?>
