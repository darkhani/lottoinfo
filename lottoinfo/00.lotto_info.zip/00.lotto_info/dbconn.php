<?php
    $db_host="localhost";
    $db_user="darkhani";
    $db_password="a4353488a";
    $db_name="darkhani";
    $conn = mysqli_connect($db_host, $db_user,$db_password, $db_name);
    
// Check connection
if (mysqli_connect_errno($conn))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

?>
