document.getElementById("drawButton").addEventListener("click", function () {
    const resultElement = document.getElementById("result");

    // Simulate lottery logic (e.g., random numbers)
    const lottoNumbers = [];
    for (let i = 0; i < 6; i++) {
        lottoNumbers.push(Math.floor(Math.random() * 45) + 1);
    }

    // Display the result
    resultElement.innerHTML = `예상번호: ${lottoNumbers.join(", ")}`;
});